// Configuración de la API
// Por definir cuando se configure el backend
export const API_URL = "";